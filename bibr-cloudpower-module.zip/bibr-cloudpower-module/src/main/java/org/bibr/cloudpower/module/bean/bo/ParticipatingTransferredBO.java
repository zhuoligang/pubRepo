package org.bibr.cloudpower.module.bean.bo;

import java.io.Serializable;

import javax.validation.constraints.NotBlank;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value = "分红划转", description = "分红划转")
public class ParticipatingTransferredBO implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "memberId")
    @NotBlank(message="memberId不能为空")
    private String memberId;

    @ApiModelProperty(value = "币种国际码")
    @NotBlank(message="币种国际码不能为空")
    private String coinCode;

    @ApiModelProperty(value = "交易数量")
    @NotBlank(message="交易数量")
    private String transactionNum;

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getCoinCode() {
        return coinCode;
    }

    public void setCoinCode(String coinCode) {
        this.coinCode = coinCode;
    }

    public String getTransactionNum() {
        return transactionNum;
    }

    public void setTransactionNum(String transactionNum) {
        this.transactionNum = transactionNum;
    }
}
