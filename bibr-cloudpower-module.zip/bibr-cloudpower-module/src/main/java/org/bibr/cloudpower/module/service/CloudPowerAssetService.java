package org.bibr.cloudpower.module.service;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.bibr.cloudpower.module.constant.CloudPowerConstant;
import org.bibr.cloudpower.module.exception.BusinessException;
import org.bibr.cloudpower.module.util.CloudPowerUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CloudPowerAssetService {
	@Autowired
	private SafetyService safetyService;
	@Autowired
	private SecretService secretService;

	public String queryCoinAddr(Map<String, String> map, HttpServletRequest request) {
		String userId = request.getHeader("userId");
		this.safetyService.checkMerchantUser(userId);
		
		Map<String, String> map_ = this.secretService.decryptpParameter(map);
		if (map_ == null || (map_.get("memberId") == null && map_.get("coinCode") == null)) {
			throw new BusinessException(CloudPowerConstant.CODE_500, CloudPowerConstant.FILL_IN_REQUIRED);
		}
		this.safetyService.checkNormalUser(map_);
		
		String result = CloudPowerUtil.pulbicSend(CloudPowerConstant.URL_WALLET + "/api/verify/wallet/address/get", map,
				request);
		/*
		 * 记录日志
		 */
		this.safetyService.addLog(userId, "用户：" + userId + "查询用户[" + map_.get("memberId") + "]冲币地址");
		return result;
	}

}
