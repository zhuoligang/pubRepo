package org.bibr.cloudpower.module.controller.api;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.bibr.cloudpower.module.bean.vo.ResultVO;
import org.bibr.cloudpower.module.constant.CloudPowerConstant;
import org.bibr.cloudpower.module.service.CloudPowerAssetService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@Controller
@RequestMapping("/verify/asset/")
@Api(value = "云算力资产系列控制台")
public class CloudPowerAssetApiController {

	private final static Logger logger = LoggerFactory.getLogger(CloudPowerAssetApiController.class);

	@Autowired
	private CloudPowerAssetService cloudPowerAssetService;

	// 1、 用户的ID对应的个人充币地址

	@ApiOperation(value = "查询用户的ID对应的个人充币地址————zlg", notes = "用户id    memberId（必填）<br>币种国际码    coinCode（必填）")
	@RequestMapping(value = "queryCoinAddr", method = RequestMethod.POST)
	@ResponseBody
	public ResultVO<String> queryCoinAddr(
			@RequestBody @ApiParam(name = "条件map", value = "jeson格式map", required = true) Map<String, String> decryptpParameter,
			HttpServletRequest request) {
		logger.info("&UserCenterMode&CloudPowerAssetApiController&queryCoinAddr&ApiStatistics");
		return new ResultVO<String>(CloudPowerConstant.CODE_200, CloudPowerConstant.SUCCESS,
				this.cloudPowerAssetService.queryCoinAddr(decryptpParameter, request));
	}
}
