package org.bibr.cloudpower.module;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 
* @ClassName: CloudPowerApplication
* @Description: TODO(资源模块启动程序)
* @author zlg
* @date 2019年9月10日下午3:22:58
*
 */
@SpringBootApplication
@MapperScan("org.bibr.cloudpower.module.dao")
public class CloudPowerApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(CloudPowerApplication.class, args);
	}
	
}
