package org.bibr.cloudpower.module.filter;

public class GlobalFilter {

}
