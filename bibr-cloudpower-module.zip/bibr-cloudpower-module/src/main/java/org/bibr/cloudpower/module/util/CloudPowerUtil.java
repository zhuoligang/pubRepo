package org.bibr.cloudpower.module.util;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.bibr.cloudpower.module.constant.CloudPowerConstant;
import org.bibr.cloudpower.module.exception.BusinessException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

public class CloudPowerUtil {
	private final static Logger logger = LoggerFactory.getLogger(CloudPowerUtil.class);
	
	/**
	 * uuid生产
	 * 
	 * @return
	 */
	public static String createUUId() {
		return UUID.randomUUID().toString().replace("-", "");
	}
	
	public static String pulbicSend(String url, Map<String, String> decryptpParameter,HttpServletRequest request) {
		String result = null;
		try {
			logger.info("本次请求参数--->" + JSONObject.toJSONString(decryptpParameter));
			Map<String, String> headerMap = new HashMap<String, String>();
			if((request.getHeader("deviceType") != null && !"".equals(request.getHeader("deviceType")))){
				headerMap.put("deviceType", request.getHeader("deviceType"));
			}
			if((request.getHeader("x-forwarded-host") != null && !"".equals(request.getHeader("x-forwarded-host")))){
				headerMap.put("x-forwarded-host", request.getHeader("x-forwarded-host"));
			}
			result = RestTemplateUtil.postForEntity(url, JSONObject.toJSONString(decryptpParameter),headerMap);
			logger.info("本次返回参数--->" + result);
			Integer code = JSON.parseObject(result).getInteger("code");
			if(code != 200){
				String errorMsg = JSON.parseObject(result).getString("message");
				logger.error(errorMsg);
				throw new BusinessException(JSON.parseObject(result).getIntValue("code"), errorMsg);
			}
//			String data = JSON.parseObject(result).getString("data");
//			System.out.println(data);
		}catch (BusinessException e) {
			logger.error(e.getMessage(), e);
			throw new BusinessException(e.getCode(), e.getMessage());
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			throw new BusinessException(CloudPowerConstant.CODE_500, e.getMessage());
		}
		return result;
	}
	
//	public static String pulbicSend(String url, Map<String, String> decryptpParameter) {
//		String result = null;
//		try {
//			logger.info("本次请求参数--->" + JSONObject.toJSONString(decryptpParameter));
//			result = RestTemplateUtil.postForEntity(url, JSONObject.toJSONString(decryptpParameter));
//			logger.info("本次返回参数--->" + result);
//			Integer code = JSON.parseObject(result).getInteger("code");
//			if(code != 200){
//				String errorMsg = JSON.parseObject(result).getString("message");
//				logger.error(errorMsg);
//				throw new BusinessException(JSON.parseObject(result).getIntValue("code"), errorMsg);
//			}
////			String data = JSON.parseObject(result).getString("data");
////			System.out.println(data);
//		}catch (BusinessException e) {
//			logger.error(e.getMessage(), e);
//			throw new BusinessException(e.getCode(), e.getMessage());
//		} catch (Exception e) {
//			logger.error(e.getMessage(), e);
//			throw new BusinessException(CloudPowerConstant.CODE_500, e.getMessage());
//		}
//		return result;
//	}
}
