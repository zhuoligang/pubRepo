package org.bibr.cloudpower.module.bean.po;

import java.util.Date;

public class BibrThirdWhiteList {
    private Integer id;

    private Integer thirdId;

    private String thirdIp;

    private Date regTime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getThirdId() {
        return thirdId;
    }

    public void setThirdId(Integer thirdId) {
        this.thirdId = thirdId;
    }

    public String getThirdIp() {
        return thirdIp;
    }

    public void setThirdIp(String thirdIp) {
        this.thirdIp = thirdIp == null ? null : thirdIp.trim();
    }

    public Date getRegTime() {
        return regTime;
    }

    public void setRegTime(Date regTime) {
        this.regTime = regTime;
    }
}