package org.bibr.cloudpower.module.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.bibr.cloudpower.module.bean.po.BibrThirdUser;

public interface BibrThirdUserMapper {
	int deleteByPrimaryKey(String id);

	int insert(BibrThirdUser record);

	int insertSelective(BibrThirdUser record);

	BibrThirdUser selectByPrimaryKey(String id);

	int updateByPrimaryKeySelective(BibrThirdUser record);

	int updateByPrimaryKey(BibrThirdUser record);
	/*
	 * 根据userId，memberId，mobile查询
	 */
	BibrThirdUser selectByMap(Map<String, String> map);
	/*
	 * 根据批量memberId查询
	 */
	List<BibrThirdUser> selectByMemberIds(Map<String, Object> map);
}