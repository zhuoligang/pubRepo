package org.bibr.cloudpower.module.conf.redis;

import java.util.Collection;
import java.util.List;
import java.util.Set;

import org.bibr.cloudpower.module.util.Json2Obj;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.core.RedisCallback;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;

/**
 * redis缓存
 * 
 * @author zlg
 * 
 */
@Component
public class RedisCache {

	@Autowired
	private RedisTemplate<String, String> redisTemplate;
	
    /**
     * 设置指定 key 的值
     * @param key
     * @param value
     */
    public void set(String key, String value) {
        redisTemplate.opsForValue().set(key, value);
    }
	
	public <T> void putCacheWithExpireTime(String key, String obj, final long expireTime) {
		final byte[] bkey = key.getBytes();
		final byte[] bvalue = obj.getBytes();
		redisTemplate.execute(new RedisCallback<Boolean>() {
			@Override
			public Boolean doInRedis(RedisConnection connection) throws DataAccessException {
				connection.setEx(bkey, expireTime, bvalue);
				return true;
			}
		});
	}

	public <T> void putCacheWithExpireTime(String key, T obj, final long expireTime) {
		final byte[] bkey = key.getBytes();
		String value = JSON.toJSONString(obj);
		final byte[] bvalue = value.getBytes();
		redisTemplate.execute(new RedisCallback<Boolean>() {
			@Override
			public Boolean doInRedis(RedisConnection connection) throws DataAccessException {
				connection.setEx(bkey, expireTime, bvalue);
				return true;
			}
		});
	}

	public String getCache(final String key) {
		//如果返回null，说明key不存在；如果返回""，说明key存在，值为""----业务上需要判断
		return redisTemplate.opsForValue().get(key);
	}
	/**
	 * 
	* @Title: getCacheDim
	* @Description: TODO(模糊查询)
	* @param @param key
	* @param @return    设定文件
	* @return String    返回类型
	* @throws
	 */
	public Set<String> getCacheDim(final String key) {
		//如果返回null，说明key不存在；如果返回""，说明key存在，值为""----业务上需要判断
		return redisTemplate.keys("*"+key+"*");
	}

	public <T> T getCache(final String key, Class<T> targetClass) {
		byte[] result = redisTemplate.execute(new RedisCallback<byte[]>() {
			@Override
			public byte[] doInRedis(RedisConnection connection) throws DataAccessException {
				return connection.get(key.getBytes());
			}
		});
		if (result == null) {
			return null;
		}
		String str = new String(result);
		return Json2Obj.j2o(str, targetClass);
	}

	/**
	 * 精确删除key
	 * 
	 * @param key
	 */
	public void deleteCache(String key) {
		redisTemplate.delete(key);
	}

	/**
	 * 模糊删除key
	 * 
	 * @param pattern
	 */
	public void deleteCacheWithPattern(String pattern) {
		Set<String> keys = redisTemplate.keys(pattern);
		redisTemplate.delete(keys);
	}

	/**
	 * 清空所有缓存
	 */
//	public void clearCache() {
//		deleteCacheWithPattern(UserCenterConstant.USER_CACHENAME + "|*");
//	}
	
	/**
	 * 存储在list头部
	 *
	 * @param key
	 * @param value
	 * @return
	 */
	public Long lLeftPush(String key, String value) {
		return redisTemplate.opsForList().leftPush(key, value);
	}
	
	/**
	 * 获取集合的元素, 从小到大排序
	 *
	 * @param key
	 * @param start 开始位置
	 * @param end   结束位置, -1查询所有
	 * @return
	 */
	public List<String> lRange(String key, long start, long end) {
		return redisTemplate.opsForList().range(key, start, end);
	}
	
    /**
    * 批量存储list
    * @param key
    * @param value
    * @return
    */
   public Long lLeftPushAll(String key, Collection<String> value) {
       return redisTemplate.opsForList().leftPushAll(key, value);
   }
   
   /**
    * 判断集合是否包含value
    *
    * @param key
    * @param value
    * @return
    */
   public Boolean sIsMember(String key, Object value) {
       return redisTemplate.opsForSet().isMember(key, value);
   }
   
   /**
    * 获取存储在哈希表中指定字段的值
    *
    * @param key
    * @param field
    * @return
    */
   public Object hGet(String key, String field) {
       return redisTemplate.opsForHash().get(key, field);
   }
}
