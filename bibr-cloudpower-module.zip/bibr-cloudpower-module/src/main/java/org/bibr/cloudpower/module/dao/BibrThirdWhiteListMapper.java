package org.bibr.cloudpower.module.dao;

import java.util.List;

import org.bibr.cloudpower.module.bean.po.BibrThirdWhiteList;

public interface BibrThirdWhiteListMapper {
	int deleteByPrimaryKey(Integer id);

	int insert(BibrThirdWhiteList record);

	int insertSelective(BibrThirdWhiteList record);

	BibrThirdWhiteList selectByPrimaryKey(Integer id);

	int updateByPrimaryKeySelective(BibrThirdWhiteList record);

	int updateByPrimaryKey(BibrThirdWhiteList record);

	List<String> selectWhiteList();
}