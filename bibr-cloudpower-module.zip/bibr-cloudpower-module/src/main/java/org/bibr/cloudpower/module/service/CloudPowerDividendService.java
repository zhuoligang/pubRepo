package org.bibr.cloudpower.module.service;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.bibr.cloudpower.module.bean.bo.ParticipatingTransferredBO;
import org.bibr.cloudpower.module.bean.po.BibrThirdUser;
import org.bibr.cloudpower.module.constant.CloudPowerConstant;
import org.bibr.cloudpower.module.dao.BibrThirdUserMapper;
import org.bibr.cloudpower.module.exception.BusinessException;
import org.bibr.cloudpower.module.util.CloudPowerUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;

@Service
public class CloudPowerDividendService {
	private final static Logger logger = LoggerFactory.getLogger(CloudPowerDividendService.class);
	@Autowired
	private BibrThirdUserMapper bibrThirdUserDao;
	@Autowired
	private SafetyService safetyService;
	
	public String transferToMemberIds(Map<String, String> map, HttpServletRequest request) {
		if (map == null || map.get("datas") == null) {
			throw new BusinessException(CloudPowerConstant.CODE_500, CloudPowerConstant.FILL_IN_REQUIRED);
		}

		String userId = request.getHeader("userId");
		this.safetyService.checkMerchantUser(userId);
		Set<String> memberIds = new HashSet<String>();// 需要验证的被操作用户集合
		try {
			String datas = map.get("datas");
			List<ParticipatingTransferredBO> list = JSON.parseArray(datas, ParticipatingTransferredBO.class);
			for (ParticipatingTransferredBO pt : list) {
				if(!memberIds.contains(pt.getMemberId())){
					memberIds.add(pt.getMemberId());
				}
			}
			this.safetyService.checkNormalUsers(memberIds);// 批量校验被操作用户
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			throw new BusinessException(CloudPowerConstant.CODE_500, e.getMessage());
		}
		// 合法校验完成，调用相关模块
		map.put("userId", userId);
		map.put("streamType", "102");//第三方分红
		String result = CloudPowerUtil.pulbicSend(
				CloudPowerConstant.URL_ASSET + "/api/verify/asset/account/participatingTransferred", map, request);
		/*
		 * 记录日志
		 */
		this.safetyService.addLog(userId, "用户：" + userId + "进行分红操作[" + JSON.toJSONString(memberIds) + "]");
		return result;
	}

	public String transferToMerchant(Map<String, String> map, HttpServletRequest request) {
		if (map == null || map.get("toMemberId") == null || map.get("coinCode") == null
				|| map.get("quantity") == null|| map.get("userRemark") == null|| map.get("toMemberRemark") == null) {
			throw new BusinessException(CloudPowerConstant.CODE_500, CloudPowerConstant.FILL_IN_REQUIRED);
		}
		map.put("memberId", map.get("toMemberId"));
		//支付行为，需要验证被动方是不是商家
		BibrThirdUser bibrThirdUser = this.bibrThirdUserDao.selectByMap(map);
		if(bibrThirdUser == null || bibrThirdUser.getUserLevel() != 1){
			throw new BusinessException(CloudPowerConstant.CODE_500, "您不能向商家以外的用户执行划转操作");
		}
		String userId = request.getHeader("userId");
		map.put("userId", userId);
		map.put("streamType", "101");//第三方支付
		String result = CloudPowerUtil.pulbicSend(
				CloudPowerConstant.URL_ASSET + "/api/verify/asset/account/assetAccountTransferred", map, request);
		/*
		 * 记录日志
		 */
		this.safetyService.addLog(userId, "用户：" + userId + "进行划转至商家（支付）操作[" + map.get("toMemberId") + "]");
		return result;
	}

}
