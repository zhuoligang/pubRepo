package org.bibr.cloudpower.module.controller.api;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.bibr.cloudpower.module.bean.vo.ResultVO;
import org.bibr.cloudpower.module.constant.CloudPowerConstant;
import org.bibr.cloudpower.module.service.CloudPowerTransferService;
import org.bibr.cloudpower.module.service.SecretService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@Controller
@RequestMapping("/verify/transfer/")
@Api(value = "云算力内部转账控制台")
public class CloudPowerTransferApiController {
	private final static Logger logger = LoggerFactory.getLogger(CloudPowerTransferApiController.class);

	@Autowired
	private CloudPowerTransferService cloudPowerTransferService;

	@Autowired
	private SecretService secretService;

	// 1、 交易所商家账户资产信息（BTC与USDT）
	// 2、 用户资产划转至商家的流水记录
	// 3、 商家资产划转至用户的流水记录

	/**
	 * 
	 * @Title: sendNotePlus @Description: TODO(查询商家指定币种资产信息) @param @param
	 *         map @param @return 设定文件 @return ResultVO<String> 返回类型 @throws
	 */
	@ApiOperation(value = "查询商家指定币种资产信息【交易所商家账户资产信息（BTC与USDT）】————zlg", notes = "用户ID    userId（必填）<br> "
			+ "查询币种【多币种用,隔开】    coinCodes（必填）")
	@RequestMapping(value = "/querySpecifiedAsset", method = RequestMethod.POST)
	@ResponseBody
	public ResultVO<String> querySpecifiedAsset(
			@RequestBody @ApiParam(name = "条件map", value = "jeson格式map", required = true) Map<String, String> map,
			HttpServletRequest request) {
		logger.info("&CloudPowerMode&CloudPowerTransferApiController&querySpecifiedAsset&ApiStatistics");
		Map<String, String> decryptpParameter = this.secretService.decryptpParameter(map);
		return new ResultVO<String>(CloudPowerConstant.CODE_200, CloudPowerConstant.SUCCESS,
				this.cloudPowerTransferService.querySpecifiedAsset(decryptpParameter, request));
	}

	/**
	 * 
	 * @Title: queryTransferRecords @Description:
	 *         TODO(查询用户到指定用户的划转流水记录) @param @param map @param @return
	 *         设定文件 @return ResultVO<String> 返回类型 @throws
	 */
	@ApiOperation(value = "查询用户到指定用户的划转流水记录————zlg", notes = "当前页：pageNumber-必填<br>" + "每页条数：pageSize-必填<br>"
			+ "用户ID：memberId-必填<br>"
			+ "流水类型：streamType(1挂单买入 ，2购币支出，3挂单卖出，4售币收入，5法币转入，6币币转出，7充币转入，8提币转出，9分红，10其他)-非必填<br>"
			+ "币种国际码：coinCode-非必填<br>" + "开始日期：startTime-非必填<br>" + "结束时间：endTime-非必填<br>")
	@RequestMapping(value = "/queryTransferRecords", method = RequestMethod.POST)
	@ResponseBody
	public ResultVO<String> queryTransferRecords(
			@RequestBody @ApiParam(name = "条件map", value = "jeson格式map", required = true) Map<String, String> map,
			HttpServletRequest request) {
		logger.info("&CloudPowerMode&CloudPowerTransferApiController&queryTransferRecords&ApiStatistics");
		Map<String, String> decryptpParameter = this.secretService.decryptpParameter(map);
		return new ResultVO<String>(CloudPowerConstant.CODE_200, CloudPowerConstant.SUCCESS,
				this.cloudPowerTransferService.queryTransferRecords(decryptpParameter, request));
	}

}
