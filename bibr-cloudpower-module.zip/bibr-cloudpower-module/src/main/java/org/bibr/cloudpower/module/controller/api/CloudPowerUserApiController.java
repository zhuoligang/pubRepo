package org.bibr.cloudpower.module.controller.api;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.bibr.cloudpower.module.bean.vo.ResultVO;
import org.bibr.cloudpower.module.constant.CloudPowerConstant;
import org.bibr.cloudpower.module.service.CloudPowerUserService;
import org.bibr.cloudpower.module.service.SecretService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@Controller
@RequestMapping("/user/")
@Api(value = "云算力用户系列控制台")
public class CloudPowerUserApiController {

	private final static Logger logger = LoggerFactory.getLogger(CloudPowerUserApiController.class);

	@Autowired
	private CloudPowerUserService cloudPowerUserService;
	@Autowired
	private SecretService secretService;

	// 1、 注册
	// 2、 登录
	// 3、 实名认证
	// 4、 查询用户信息，主要是用户的ID
	// 5、 二次验证绑定
	// 6、 资金安全码
	@ApiOperation(value = "注册基本信息审核————zlg",
			notes = "手机号		mobile（必填）")
	@RequestMapping(value = "pass/checkRegister", method = RequestMethod.POST)
	@ResponseBody
	public ResultVO<String> checkRegister(@RequestBody @ApiParam(name = "条件map",
            value = "jeson格式map", required = true) Map<String, String> decryptpParameter,HttpServletRequest request) {
		logger.info("&CloudPowerMode&UserCenterFrontController&checkRegister&ApiStatistics");
		return new ResultVO<String>(CloudPowerConstant.CODE_200, CloudPowerConstant.SUCCESS,
				this.cloudPowerUserService.checkRegister(decryptpParameter, request));
	}

	@ApiOperation(value = "发送短信/邮箱验证码————zlg", notes = "手机号/邮箱    mobile（必填）<br>该条验证码关联的接口调用地址    noteType（必填）")
	@RequestMapping(value = "pass/sendNotePlus", method = RequestMethod.POST)
	@ResponseBody
	public ResultVO<String> sendNotePlus(
			@RequestBody @ApiParam(name = "条件map", value = "jeson格式map", required = true) Map<String, String> decryptpParameter,
			HttpServletRequest request) {
		logger.info("&CloudPowerMode&CloudPowerUserApiController&sendNotePlus&ApiStatistics");
		return new ResultVO<String>(CloudPowerConstant.CODE_200, CloudPowerConstant.SUCCESS,
				this.cloudPowerUserService.sendNotePlus(decryptpParameter, request));
	}

	@ApiOperation(value = "注册————zlg", notes = "手机号		mobile（必填）<br>密码		password（必填）<br>短信验证码		mobileVcode（必填<br>"
			+ "推荐码		parentId（非必填）<br>商家标记    flag（非必填）")
	@RequestMapping(value = "pass/register", method = RequestMethod.POST)
	@ResponseBody
	public ResultVO<String> register(
			@RequestBody @ApiParam(name = "条件map", value = "jeson格式map", required = true) Map<String, String> decryptpParameter,
			HttpServletRequest request) {
		logger.info("&CloudPowerMode&CloudPowerUserApiController&register&ApiStatistics");
		return new ResultVO<String>(CloudPowerConstant.CODE_200, CloudPowerConstant.SUCCESS,
				this.cloudPowerUserService.register(decryptpParameter, request));
	}

	@ApiOperation(value = "登录————zlg", notes = "手机号		username（必填）<br>密码		password（必填）<br>"
			+ "验证类型		verifyType（非必填）<br>验证码		verifyCode（非必填）")
	@ResponseBody
	@RequestMapping(value = "pass/login", method = RequestMethod.POST)
	public ResultVO<String> login(
			@RequestBody @ApiParam(name = "条件map", value = "jeson格式map", required = true) Map<String, String> decryptpParameter,
			HttpServletRequest request, HttpServletResponse response) {
		logger.info("&CloudPowerMode&CloudPowerUserApiController&login&ApiStatistics");
		return new ResultVO<String>(CloudPowerConstant.CODE_200, CloudPowerConstant.SUCCESS,
				this.cloudPowerUserService.login(decryptpParameter, request));
	}

	@ApiOperation(value = "普通实名认证————zlg", notes = "用户姓名		name<br>身份证号		idcard（必填）")
	@RequestMapping(value = "verify/certification", method = RequestMethod.POST)
	@ResponseBody
	public ResultVO<String> certification(
			@RequestBody @ApiParam(name = "条件map", value = "jeson格式map", required = true) Map<String, String> decryptpParameter,
			HttpServletRequest request) {
		logger.info("&CloudPowerMode&CloudPowerUserApiController&certification&ApiStatistics");
		return new ResultVO<String>(CloudPowerConstant.CODE_200, CloudPowerConstant.SUCCESS,
				this.cloudPowerUserService.certification(decryptpParameter, request));
	}

	@ApiOperation(value = "精确查询用户信息————zlg", notes = "用户uuid		uuid（非必填）<br> 用户memberId		memberId（非必填）<br>ps:2个字段必须存在一个")
	@RequestMapping(value = "verify/findCenterUserMain", method = RequestMethod.POST)
	@ResponseBody
	public ResultVO<String> findCenterUserMain(
			@RequestBody @ApiParam(name = "条件map", value = "jeson格式map", required = true) Map<String, String> decryptpParameter,
			HttpServletRequest request) {
		logger.info("&UserCenterMode&CloudPowerApiController&findCenterUserMain&ApiStatistics");
		return new ResultVO<String>(CloudPowerConstant.CODE_200, CloudPowerConstant.SUCCESS, this.cloudPowerUserService
				.findCenterUserMain(this.secretService.decryptpParameter(decryptpParameter), request));
	}
	
	@ApiOperation(value = "通过刷新令牌获取新的令牌————zlg", notes = "刷新令牌    refreshToken（必填）")
	@RequestMapping(value = "pass/reacquire", method = RequestMethod.POST)
	@ResponseBody
	public ResultVO<String> reacquire(
			@RequestBody @ApiParam(name = "条件map", value = "jeson格式map", required = true) Map<String, String> decryptpParameter,
			HttpServletRequest request) {
		logger.info("&UserCenterMode&CloudPowerApiController&reacquire&ApiStatistics");
		return new ResultVO<String>(CloudPowerConstant.CODE_200, CloudPowerConstant.SUCCESS, this.cloudPowerUserService
				.reacquire(this.secretService.decryptpParameter(decryptpParameter), request));
	}

}
