package org.bibr.cloudpower.module.service;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.bibr.cloudpower.module.constant.CloudPowerConstant;
import org.bibr.cloudpower.module.exception.BusinessException;
import org.bibr.cloudpower.module.util.CloudPowerUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CloudPowerTransferService {
	@Autowired
	private SafetyService safetyService;

	public String querySpecifiedAsset(Map<String, String> map, HttpServletRequest request) {
		if (map == null || map.get("userId") == null || map.get("coinCodes") == null) {
			throw new BusinessException(CloudPowerConstant.CODE_500, CloudPowerConstant.FILL_IN_REQUIRED);
		}
		String userId = request.getHeader("userId");
		this.safetyService.checkMerchantUser(userId);
		this.safetyService.checkNormalUser(map);
		String result = CloudPowerUtil.pulbicSend(
				CloudPowerConstant.URL_FINANCIAL + "/api/verify/asset/account/queryByVariableCoinCode", map, request);
		/*
		 * 记录日志
		 */
		this.safetyService.addLog(userId, "用户：" + userId + "查询[" + map.get("userId") + "]用户资产信息");
		return result;
	}

	public String queryTransferRecords(Map<String, String> map, HttpServletRequest request) {
		if (map == null || map.get("pageNumber") == null || map.get("pageSize") == null
				|| map.get("memberId") == null) {
			throw new BusinessException(CloudPowerConstant.CODE_500, CloudPowerConstant.FILL_IN_REQUIRED);
		}
		String userId = request.getHeader("userId");
		this.safetyService.checkMerchantUser(userId);
		this.safetyService.checkNormalUser(map);
		String result = CloudPowerUtil.pulbicSend(
				CloudPowerConstant.URL_FINANCIAL + "/api/verify/asset/account/queryTransferredRecord", map, request);
		/*
		 * 记录日志
		 */
		this.safetyService.addLog(userId, "用户：" + userId + "查询[" + map.get("memberId") + "]用户划转流水记录");
		return result;
	}
}
