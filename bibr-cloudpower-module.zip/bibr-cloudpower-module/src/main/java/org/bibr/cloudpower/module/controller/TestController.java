package org.bibr.cloudpower.module.controller;

import java.util.HashMap;
import java.util.Map;

import org.bibr.cloudpower.module.service.SecretService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@Controller
@RequestMapping("/test")
@Api(value = "云算力测试控制台")
public class TestController {
	// public static void main(String[] args) {
	// Map<String, String> map = new HashMap<String, String>();
	// map.put("data", "string");
	// String encryptParameter = new SecretService().encryptParameter(map);
	// System.out.println(encryptParameter);
	// Map<String, String> map2 = new HashMap<String, String>();
	// map2.put("ciphertext",encryptParameter);
	// Map<String, String> decryptpParameter = new
	// SecretService().decryptpParameter(map2);
	// System.out.println(JSONObject.toJSONString(decryptpParameter));
	// }

	@Autowired
	private SecretService secretService;

	Map<String, String> testMap = new HashMap<String, String>();

	@ApiOperation(value = "测试加密————zlg", notes = "无")
	@RequestMapping(value = "/test1", method = RequestMethod.POST)
	@ResponseBody
	public String test1(
			@RequestBody @ApiParam(name = "条件map", value = "jeson格式map", required = true) Map<String, String> map) {
		String encryptParameter = secretService.encryptParameter(map);
		// System.out.println("数据加密后。。。。。。" + encryptParameter);
		testMap.put("ciphertext", encryptParameter);
		return encryptParameter;
	}

	@ApiOperation(value = "测试解密————zlg", notes = "无")
	@RequestMapping(value = "/test2", method = RequestMethod.POST)
	@ResponseBody
	public String test2() {
		String decryptpParameter = JSONObject.toJSONString(secretService.decryptpParameter(testMap));
		System.out.println("数据解密后。。。。。。" + decryptpParameter);
		return decryptpParameter;
	}

	@ApiOperation(value = "测试解密指定密文————zlg", notes = "无")
	@RequestMapping(value = "/test3", method = RequestMethod.POST)
	@ResponseBody
	public String test3(
			@RequestBody @ApiParam(name = "条件map", value = "jeson格式map", required = true) Map<String, String> map) {
		System.out.println("原始传入数据：" + map);
		Map<String, String> map_ = secretService.decryptpParameter(map);
		String decryptpParameter = JSONObject.toJSONString(map_);
		System.out.println("数据解密后。。。。。。" + decryptpParameter);
		return decryptpParameter;
	}

}
