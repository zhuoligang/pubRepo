package org.bibr.cloudpower.module.service;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.bibr.cloudpower.module.bean.po.BibrThirdUser;
import org.bibr.cloudpower.module.constant.CloudPowerConstant;
import org.bibr.cloudpower.module.dao.BibrThirdUserMapper;
import org.bibr.cloudpower.module.exception.BusinessException;
import org.bibr.cloudpower.module.util.CloudPowerUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

@Service
public class CloudPowerUserService {
	private final static Logger logger = LoggerFactory.getLogger(CloudPowerUserService.class);
	@Autowired
	private BibrThirdUserMapper bibrThirdUserDao;
	@Autowired
	private SafetyService safetyService;

	public String sendNotePlus(Map<String, String> decryptpParameter, HttpServletRequest request) {
		String result = CloudPowerUtil.pulbicSend(CloudPowerConstant.URL_USERCENTER + "/api/cloudpower/sendNotePlus",
				decryptpParameter, request);
		//
		return result;
	}

	public String register(Map<String, String> decryptpParameter, HttpServletRequest request) {
		String result = CloudPowerUtil.pulbicSend(CloudPowerConstant.URL_USERCENTER + "/api/cloudpower/register",
				decryptpParameter, request);
		return result;
	}

	public String login(Map<String, String> decryptpParameter, HttpServletRequest request) {
		String result = CloudPowerUtil.pulbicSend(CloudPowerConstant.URL_USERCENTER + "/api/cloudpower/auth/login",
				decryptpParameter, request);
		/*
		 * 登录成功后加入用户体系
		 */
		try {
			JSONObject jsonObject = JSON.parseObject(result).getJSONObject("data").getJSONObject("centerUserMain");
			String userId = jsonObject.getString("id");
			String memberId = jsonObject.getString("memberId");
			String mobile = jsonObject.getString("mobile");
			BibrThirdUser queryUser = this.safetyService.queryUserByUserId(userId);
			if(queryUser == null){
				BibrThirdUser bibrThirdUser = new BibrThirdUser();
				bibrThirdUser.setId(CloudPowerUtil.createUUId());
				bibrThirdUser.setMemberId(memberId);
				bibrThirdUser.setMobile(mobile);
				bibrThirdUser.setUserId(userId);
				bibrThirdUser.setThirdId(1);// 临时写死，后续增加第三方可以根据第三方ip白名单反查第三方id
				int i = this.bibrThirdUserDao.insertSelective(bibrThirdUser);
				if (i < 1) {
					logger.error("用户在加入体系时出现错误");
					throw new BusinessException(CloudPowerConstant.CODE_500, "用户在加入体系时出现错误");
				}
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			throw new BusinessException(CloudPowerConstant.CODE_500, e.getMessage());
		}

		return result;
	}

	public String certification(Map<String, String> decryptpParameter, HttpServletRequest request) {
		String result = CloudPowerUtil.pulbicSend(CloudPowerConstant.URL_USERCENTER + "/api/cloudpower/certification",
				decryptpParameter, request);
		/*
		 * 记录日志
		 */
		String userId = request.getHeader("userId");
		this.safetyService.addLog(userId, "普通实名认证");
		return result;
	}

	public String findCenterUserMain(Map<String, String> map, HttpServletRequest request) {
		if (map == null || (map.get("uuid") == null && map.get("memberId") == null)) {
			throw new BusinessException(CloudPowerConstant.CODE_500, CloudPowerConstant.FILL_IN_REQUIRED);
		}
		String userId = request.getHeader("userId");
		this.safetyService.checkMerchantUser(userId);//检查操作者权限
		String arg = null;
		if(map.get("uuid") == null){
			map.put("userId", map.get("uuid"));
			arg = map.get("uuid");
		}else if(map.get("memberId") != null){
			arg = map.get("memberId");
		}
		//检查被操作者合法性
		this.safetyService.checkNormalUser(map);
		String result = CloudPowerUtil
				.pulbicSend(CloudPowerConstant.URL_USERCENTER + "/api/cloudpower/findCenterUserMain", map, request);
		/*
		 * 记录日志
		 */
		this.safetyService.addLog(userId, "用户：" + userId + "查询[" + arg + "]用户基本信息");
		return result;
	}
	
	/*
	 * 刷新令牌
	 */
	public String reacquire(Map<String, String> map, HttpServletRequest request) {
		if (map == null || map.get("refreshToken") == null ) {
			throw new BusinessException(CloudPowerConstant.CODE_500, CloudPowerConstant.FILL_IN_REQUIRED);
		}
		String userId = request.getHeader("userId");
		this.safetyService.checkMerchantUser(userId);//检查操作者权限
		map.put("userId", userId);
		
		String result = CloudPowerUtil
				.pulbicSend(CloudPowerConstant.URL_AUTH + "/reacquire", map, request);
		/*
		 * 记录日志
		 */
		this.safetyService.addLog(userId, "用户：" + userId + "刷新了令牌");
		return result;
	}

	public String checkRegister(Map<String, String> map, HttpServletRequest request) {
		String result = CloudPowerUtil.pulbicSend(CloudPowerConstant.URL_USERCENTER + "/api/cloudpower/checkRegister",
				map, request);
		return result;
	}
}
