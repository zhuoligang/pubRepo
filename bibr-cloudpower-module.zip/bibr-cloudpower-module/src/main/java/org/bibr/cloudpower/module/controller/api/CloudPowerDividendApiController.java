package org.bibr.cloudpower.module.controller.api;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.bibr.cloudpower.module.bean.bo.ParticipatingTransferredBO;
import org.bibr.cloudpower.module.bean.vo.ResultVO;
import org.bibr.cloudpower.module.constant.CloudPowerConstant;
import org.bibr.cloudpower.module.service.CloudPowerDividendService;
import org.bibr.cloudpower.module.service.SecretService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@Controller
@RequestMapping("/verify/dividend/")
@Api(value = "云算力每日分红控制台")
public class CloudPowerDividendApiController {
	private final static Logger logger = LoggerFactory.getLogger(CloudPowerDividendApiController.class);

	@Autowired
	private CloudPowerDividendService cloudPowerDividendService;

	@Autowired
	private SecretService secretService;

	public static void main(String[] args) {
		Map<String, String> sendMap = new HashMap<String, String>();
		List<ParticipatingTransferredBO> list = new ArrayList<>();
		ParticipatingTransferredBO pb1 = new ParticipatingTransferredBO();
		pb1.setMemberId("36606732");
		pb1.setCoinCode("BT");
		pb1.setTransactionNum("20");
		list.add(pb1);
		ParticipatingTransferredBO pb2 = new ParticipatingTransferredBO();
		pb2.setMemberId("29551788");
		pb2.setCoinCode("ETH");
		pb2.setTransactionNum("10");
		list.add(pb2);
		String datas = JSONObject.toJSONString(list);
		System.out.println(datas);
		sendMap.put("datas", datas);
		// sendMap.put("userId", "063c28787cdb40c0b023c86e1748ad31");
		System.out.println(JSONObject.toJSONString(sendMap));
		
//		List<ParticipatingTransferredBO> parseArray = JSON.parseArray(datas, ParticipatingTransferredBO.class);
//		System.out.println(parseArray);
	}

	@ApiOperation(value = "商家划转资金到指定用户组（分红）————zlg", notes = "分红详情【由多个分红实体类ParticipatingTransferredBO构成】    datas（必填）")
	@RequestMapping(value = "/transferToMemberIds", method = RequestMethod.POST)
	@ResponseBody
	public ResultVO<String> transferToMemberIds(
			@RequestBody @ApiParam(name = "条件map", value = "jeson格式map", required = true) Map<String, String> map,
			HttpServletRequest request) {
		logger.info("&CloudPowerMode&CloudPowerTransferApiController&transferToMemberIds&ApiStatistics");
		Map<String, String> decryptpParameter = this.secretService.decryptpParameter(map);
		return new ResultVO<String>(CloudPowerConstant.CODE_200, CloudPowerConstant.SUCCESS,
				this.cloudPowerDividendService.transferToMemberIds(decryptpParameter, request));
	}
	
	@ApiOperation(value = "用户划转资金到商家（支付）————zlg", notes = "商家     toMemberId（必填）<br>"
			+ "划转币种    coinCode（必填）<br>划转数量    quantity（必填）<br>划出备注    userRemark（必填）<br>划进备注    toMemberRemark（必填）")
	@RequestMapping(value = "/transferToMerchant", method = RequestMethod.POST)
	@ResponseBody
	public ResultVO<String> transferToMerchant(
			@RequestBody @ApiParam(name = "条件map", value = "jeson格式map", required = true) Map<String, String> map,
			HttpServletRequest request) {
		logger.info("&CloudPowerMode&CloudPowerTransferApiController&transferToMerchant&ApiStatistics");
		Map<String, String> decryptpParameter = this.secretService.decryptpParameter(map);
		return new ResultVO<String>(CloudPowerConstant.CODE_200, CloudPowerConstant.SUCCESS,
				this.cloudPowerDividendService.transferToMerchant(decryptpParameter, request));
	}

}
