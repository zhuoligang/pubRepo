package org.bibr.cloudpower.module.service;

import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.bibr.cloudpower.module.bean.po.BibrThirdLog;
import org.bibr.cloudpower.module.bean.po.BibrThirdUser;
import org.bibr.cloudpower.module.constant.CloudPowerConstant;
import org.bibr.cloudpower.module.dao.BibrThirdLogMapper;
import org.bibr.cloudpower.module.dao.BibrThirdUserMapper;
import org.bibr.cloudpower.module.dao.BibrThirdWhiteListMapper;
import org.bibr.cloudpower.module.exception.BusinessException;
import org.bibr.cloudpower.module.util.CloudPowerUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SafetyService {
	private final static Logger logger = LoggerFactory.getLogger(SafetyService.class);
	@Autowired
	private BibrThirdWhiteListMapper bibrThirdWhiteListDao;
	@Autowired
	private BibrThirdUserMapper bibrThirdUserDao;
	@Autowired
	private BibrThirdLogMapper bibrThirdLogDao;
	
	
	// ip 白名单
	public static List<String> IP_INTERNAL;

	public List<String> getIP_INTERNAL() {
		return this.bibrThirdWhiteListDao.selectWhiteList();
	}
	
	/*
	 * 查询用户
	 */
	public BibrThirdUser queryUserByUserId(String userId){
		Map<String,String> map = new HashMap<String, String>();
		map.put("userId", userId);
		BibrThirdUser bibrThirdUser = this.bibrThirdUserDao.selectByMap(map);
		return bibrThirdUser;
	}
	
	/*
	 * 操作人权限校验（是否是商家）
	 */
	public void checkMerchantUser(String userId){
		BibrThirdUser bibrThirdUser = queryUserByUserId(userId);
		if (bibrThirdUser.getUserLevel() != 1) {
			logger.error("用户没有该操作的权限");
			throw new BusinessException(CloudPowerConstant.CODE_500, "用户没有该操作的权限");
		}
	}
	/*
	 * 校验被操作人合法性
	 */
	public void checkNormalUser(Map<String,String> map){
		BibrThirdUser bibrThirdUser = this.bibrThirdUserDao.selectByMap(map);
		if(bibrThirdUser == null){
			logger.error("被操作用户不在您的用户体系");
			throw new BusinessException(CloudPowerConstant.CODE_500, "被操作用户不在您的用户体系");
		}
	}
	
	public static void main(String[] args) {
		Set<String> memberIds = new HashSet<String>();
		memberIds.add("13");
		memberIds.add("23");
		System.out.println(memberIds);
		String[] bb = memberIds.toArray(new String[memberIds.size()]);
		System.out.println(bb);
	}
	/*
	 * 批量校验被操作人
	 */
	public void checkNormalUsers(Set<String> memberIds){
		Map<String,Object> map = new HashMap<>();
		String[] args = memberIds.toArray(new String[memberIds.size()]);
		map.put("memberIds", args);
		List<BibrThirdUser> list = this.bibrThirdUserDao.selectByMemberIds(map);
		if(list == null || list.size() < memberIds.size()){
			logger.error("存在用户体系外的被操作帐号");
			throw new BusinessException(CloudPowerConstant.CODE_500, "存在用户体系外的被操作帐号");
		}
	}
	
	/*
	 * 添加操作日志
	 */
	public void addLog(String userId ,String content){
		BibrThirdUser queryUser = queryUserByUserId(userId);
		BibrThirdLog bibrThirdLog = new BibrThirdLog();
		bibrThirdLog.setId(CloudPowerUtil.createUUId());
		bibrThirdLog.setContent(content);
		bibrThirdLog.setMemberId(queryUser.getMemberId());
		bibrThirdLog.setRegTime(new Date());
		bibrThirdLog.setThirdId(1);
		bibrThirdLog.setUserId(userId);
		int i = this.bibrThirdLogDao.insertSelective(bibrThirdLog);
		if(i < 1){
			logger.error("写入操作日志错误");
			throw new BusinessException(CloudPowerConstant.CODE_500, "写入操作日志错误");
		}
	}
}
