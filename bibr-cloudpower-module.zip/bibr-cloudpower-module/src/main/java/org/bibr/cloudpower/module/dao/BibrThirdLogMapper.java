package org.bibr.cloudpower.module.dao;

import org.bibr.cloudpower.module.bean.po.BibrThirdLog;

public interface BibrThirdLogMapper {
    int deleteByPrimaryKey(String id);

    int insert(BibrThirdLog record);

    int insertSelective(BibrThirdLog record);

    BibrThirdLog selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(BibrThirdLog record);

    int updateByPrimaryKey(BibrThirdLog record);
}