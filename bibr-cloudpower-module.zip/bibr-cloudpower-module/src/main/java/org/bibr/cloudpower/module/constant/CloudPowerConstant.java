package org.bibr.cloudpower.module.constant;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class CloudPowerConstant {
	// 通讯成功
	public static final int CODE_200 = 200;
	// 失败
	public static final int CODE_500 = 500;
	
	public static final String SUCCESS = "success";
	
	public static final String FAILURE = "failure";
	
	public static final String KEYWORDS_SUCCESS = "成功";
	
	public static final String KEYWORDS_FAILURE = "失败";
	
	public static final String FILL_IN_REQUIRED ="请规范填写必填内容";
	//解密参数出现错误
	public static final String DECRYPTP_PARAMETER_ERROR = "网络繁忙，请稍后再试";
	
	public static final String TIME_INTERVAL_IS_TOO_LONG = "时间间隔太长";
	

	//涉及用户中心接口地址
	public static String URL_USERCENTER;
	@Value("${url.usercenter}")
	public void setURL_USERCENTER(String uRL_USERCENTER) {
		URL_USERCENTER = uRL_USERCENTER;
	}
	
	//涉及资产接口地址
	public static String URL_ASSET;
	@Value("${url.asset}")
	public void setURL_ASSET(String uRL_ASSET) {
		URL_ASSET = uRL_ASSET;
	}
	
	//涉及钱包接口地址
	public static String URL_WALLET;
	@Value("${url.wallet}")
	public void setURL_WALLET(String uRL_WALLET) {
		URL_WALLET = uRL_WALLET;
	}
	
	//涉及认证中心接口地址
	public static String URL_AUTH;
	@Value("${url.auth}")
	public void setURL_AUTH(String uRL_AUTH) {
		URL_AUTH = uRL_AUTH;
	}
	
	//财务中心接口地址
	public static String URL_FINANCIAL;
	@Value("${url.financial}")
	public void setURL_FINANCIAL(String uRL_FINANCIAL) {
		URL_FINANCIAL = uRL_FINANCIAL;
	}
}
